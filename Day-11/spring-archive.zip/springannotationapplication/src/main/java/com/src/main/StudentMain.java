package com.src.main;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.src.annotated.StudentConfig;

import springfirstapplication.Student;

public class StudentMain {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext();
		
		ctx.register(StudentConfig.class);
		ctx.refresh();
		
		
		
		Student s1 = (Student) ctx.getBean("std1");
		
		System.out.println(s1);
		
		Student s2 = (Student) ctx.getBean("std2");
		
		System.out.println(s2);

	}

}
