package com.src.bean;

public class DataBase {
	
	private DataSource  ds;


	public DataSource getDs() {
		return ds;
	}


	public void setDs(DataSource ds) {
		this.ds = ds;
	}


	public DataBase() {
		super();
		// TODO Auto-generated constructor stub
	}


	public DataBase(DataSource ds) {
		super();
		this.ds = ds;
	}
	
	

}
