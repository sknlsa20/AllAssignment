package springfirstapplication;

public class Student {
	
	private int stdid;
	private String stdname;
	private String stdaddress;
	private long stdmob;
	
	
	@Override
	public String toString() {
		return "Student [stdid=" + stdid + ", stdname=" + stdname + ", stdaddress=" + stdaddress + ", stdmob=" + stdmob
				+ "]";
	}
	public int getStdid() {
		return stdid;
	}
	public void setStdid(int stdid) {
		this.stdid = stdid;
	}
	public String getStdname() {
		return stdname;
	}
	public void setStdname(String stdname) {
		this.stdname = stdname;
	}
	public String getStdaddress() {
		return stdaddress;
	}
	public void setStdaddress(String stdaddress) {
		this.stdaddress = stdaddress;
	}
	public long getStdmob() {
		return stdmob;
	}
	public void setStdmob(long stdmob) {
		this.stdmob = stdmob;
	}
	
	

}
