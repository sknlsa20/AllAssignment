package com.src.annotated;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfirstapplication.Student;

@Configuration
public class StudentConfig {
	
	@Bean(name="std1")
	public Student student1()
	{
		Student s =new Student();
		s.setStdid(555);
		s.setStdname("saxena");
		s.setStdmob(78787878);
		s.setStdaddress("USA");
		
		return s;
	}
	

	@Bean(name = "std2")
	public Student student2()
	{
		Student s =new Student();
		s.setStdid(7878);
		s.setStdname("kumaran");
		s.setStdmob(9999999);
		s.setStdaddress("Canada");
		
		return s;
	}

}
