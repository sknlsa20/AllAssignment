package com.src.mn;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.src.bean.Question;

public class MapSpringEx {

	public static void main(String[] args) {


		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Question q = (Question) context.getBean("que1");
		
		System.out.println(q);
		
		Question q1=(Question) context.getBean("que2");
		System.out.println(q1);

	}

}
