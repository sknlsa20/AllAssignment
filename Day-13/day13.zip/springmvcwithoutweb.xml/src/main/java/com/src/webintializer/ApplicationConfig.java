package com.src.webintializer;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.src.dao.StudentDAOClass;
import com.src.dao.StudentDAOInterface;

import org.springframework.jdbc.datasource.DriverManagerDataSource;


@EnableWebMvc
@Configuration
@ComponentScan(basePackages = {"com.src.controller","com.src.dao"})
public class ApplicationConfig {
	
	@Bean
	public InternalResourceViewResolver general()
	{		
		InternalResourceViewResolver irv=new InternalResourceViewResolver();
		irv.setPrefix("/WEB-INF/jsp/");
		irv.setSuffix(".jsp");
		return irv;
	}
	
	@Bean
	public StudentDAOClass DaoObject()
	{
		StudentDAOClass stddao = new StudentDAOClass();		
		stddao.setJdbctemplate(jdbcObject());		
		return stddao;
	}

	@Bean
	public JdbcTemplate jdbcObject()
	{
		JdbcTemplate jdbctemp = new JdbcTemplate();		
		jdbctemp.setDataSource(getDataSource());		
		return jdbctemp;
	}
	
	@Bean
	public DriverManagerDataSource getDataSource()
	{
		DriverManagerDataSource ds =new DriverManagerDataSource();
		ds.setDriverClassName("com.mysql.cj.jdbc.Driver");
		ds.setUrl("jdbc:mysql://localhost/shivadb");
		ds.setUsername("root");
		ds.setPassword("root");
		
		return ds;
		
		
	}
}
