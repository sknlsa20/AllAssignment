package com.src.conf;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.src.model.Address;
import com.src.model.Student;

@Configuration
public class MyBeanConfiguration {
	
	
	@Bean("std")
	public Student getStd1()
	{
		List<Address> al = new ArrayList();
		al.add(getstd1add());
		al.add(getstd2add());
		
		return new Student(420,"sk",al);
	}
	
	@Bean("add1")
	public Address getstd1add()
	{
		return new Address(456,"my street","my city","my state",79798098);
	}
	
	@Bean("add2")
	public Address getstd2add()
	{
		return new Address(789,"your street","your city","your state",44577);
	}
	
	
	
	@Bean("std1")
	public Student getStd2()
	{
		List<Address> al = new ArrayList();
		al.add(getstd1add1());
		al.add(getstd2add2());
		
		Student s = new Student();
		s.setStdid(777);
		s.setStdname("kk");
		s.setStdaddress(al);
		
		return s;

	}
	
	@Bean("add3")
	public Address getstd1add1()
	{
		Address ad = new Address();
		ad.setHno(888);
		ad.setStreetname("sathya nagar");
		ad.setCity("chennai");
		ad.setState("tamil naidu");
		ad.setPin(76766666);
		return ad;
	}
	
	@Bean("add4")
	public Address getstd2add2()
	{
		Address ad = new Address();
		ad.setHno(999);
		ad.setStreetname("gadhi nagar");
		ad.setCity("mumbai");
		ad.setState("maharashtra");
		ad.setPin(3234455);
		return ad;
	}

}
