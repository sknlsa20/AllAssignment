package com.src;

public interface Shape {

	public void draw();
}


class Triangle implements Shape
{
	public void draw()
	{
		System.out.println("draw a triangle");
	}
}

class Circle implements Shape
{
	public void draw()
	{
		System.out.println("draw a circle");
	}
}

class Rectangle implements Shape
{
	public void draw()
	{
		System.out.println("draw a rectangle");
	}

}
