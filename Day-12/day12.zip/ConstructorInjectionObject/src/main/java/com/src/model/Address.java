package com.src.model;

public class Address {
	
	private int hno;
	private String streetname;
	private String city;
	private String state;
	private long pincode;
	
	public void setHno(int hno) {
		this.hno = hno;
	}

	public void setStreetname(String streetname) {
		this.streetname = streetname;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public Address(int hno, String streetname, String city, String state, long pincode) {
		
		this.hno = hno;
		this.streetname = streetname;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}

	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getHno() {
		return hno;
	}

	public String getStreetname() {
		return streetname;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public long getPincode() {
		return pincode;
	}

	@Override
	public String toString() {
		return "Address [hno=" + hno + ", streetname=" + streetname + ", city=" + city + ", state=" + state
				+ ", pincode=" + pincode + "]";
	}
	
	
	
	
	
	

}
