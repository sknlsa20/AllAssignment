package com.src.model;

public class Student {
	
	private int stdid;
	private String stdname;
	private Address stdadd;
	
	public void setStdid(int stdid) {
		this.stdid = stdid;
	}
	public void setStdname(String stdname) {
		this.stdname = stdname;
	}
	public void setStdadd(Address stdadd) {
		this.stdadd = stdadd;
	}
	public Student(int stdid, String stdname, Address stdadd) {
		super();
		this.stdid = stdid;
		this.stdname = stdname;
		this.stdadd = stdadd;
	}
	
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getStdid() {
		return stdid;
	}
	public String getStdname() {
		return stdname;
	}
	public Address getStdadd() {
		return stdadd;
	}
	@Override
	public String toString() {
		return "Student [stdid=" + stdid + ", stdname=" + stdname + ", stdadd=" + stdadd + "]";
	}
	
	
	

}
