package com.src.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.src.model.Employee;

public class EmployeeDAO implements EmployeeDaoInterface{

	Connection con;
	PreparedStatement stmt;
	public static final String driver_class="com.mysql.cj.jdbc.Driver";
	public static final String url="jdbc:mysql://localhost/shivadb";
	public static final String user="root";
	public static final String password="root";
	@Override
	public void getConnection() {
		try {
			Class.forName(driver_class);
			con=DriverManager.getConnection(url,user,password);
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public boolean validateEmployee(Employee e) {
		
		String sqlquery="select * from employee where empid=? and emppassword=?";
		try {
			stmt=con.prepareStatement(sqlquery);
			
			stmt.setString(1, e.getEmpId());
			stmt.setString(2, e.getEmpPwd());
			
			return stmt.execute();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return false;
	}

	@Override
	public int insertEmployee(Employee e) {
		String sqlquery="insert into employee values(?,?,?,?,?,?)";
		try {
			stmt=con.prepareStatement(sqlquery);
			
			stmt.setString(1, e.getEmpId());
			stmt.setString(2, e.getEmpPwd());
			stmt.setString(3, e.getEmpName());
			stmt.setInt(4, e.getEmpAge());
			stmt.setLong(5, e.getEmpmobile());
			stmt.setString(6, e.getEmpaddress());
			
			return stmt.executeUpdate();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return 0;
	}

	@Override
	public int deleteEmployee(Employee e) {
		String sqlquery="delete from employee where empid=?";
		try {
			stmt=con.prepareStatement(sqlquery);			
			stmt.setString(1, e.getEmpId());			
			return stmt.executeUpdate();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return 0;
	}

	@Override
	public int editEmployee(Employee e) {
		String sqlquery="update employee set emppassword=?,empname=?,empage=?,empmob=?,empaddress=? where empid=?";
		try {
			stmt=con.prepareStatement(sqlquery);
			
			
			stmt.setString(1, e.getEmpPwd());
			stmt.setString(2, e.getEmpName());
			stmt.setInt(3, e.getEmpAge());
			stmt.setLong(4, e.getEmpmobile());
			stmt.setString(5, e.getEmpaddress());
			stmt.setString(6, e.getEmpId());
			
			return stmt.executeUpdate();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return 0;
	}

	@Override
	public ArrayList<Employee> displayEmployees() {
		ArrayList<Employee> emps=new ArrayList();
		String sqlquery="select * from employee";
		try {
			stmt=con.prepareStatement(sqlquery);			
			
			ResultSet rs=stmt.executeQuery();
			while(rs.next())
			{
				emps.add(new Employee(rs.getString(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getLong(5),rs.getString(6)));
			}
			
			return emps;
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return emps;
	}

	@Override
	public Employee getEmployeeById(String id) {
		String sqlquery="select * from employee where empid=?";
		try {
			stmt=con.prepareStatement(sqlquery);			
			stmt.setString(1, id);			
			ResultSet rs=stmt.executeQuery();
			if(rs.next())
			{
				return new Employee(rs.getString(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getLong(5),rs.getString(6));
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return null;
	}

	@Override
	public void closeConnection() {
		try {
			con.close();
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
