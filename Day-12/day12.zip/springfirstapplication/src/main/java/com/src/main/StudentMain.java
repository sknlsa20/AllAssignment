package com.src.main;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import springfirstapplication.Student;

public class StudentMain {

	public static void main(String[] args) {

		Resource resource = new ClassPathResource("applicationContext.xml");
		
		BeanFactory factory=new XmlBeanFactory(resource);
		
		Student s1 = (Student) factory.getBean("std");
		
		System.out.println(s1);
		
		Student s2 = (Student) factory.getBean("std1");
		
		System.out.println(s2);

	}

}
