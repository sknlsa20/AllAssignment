package com.src.bean;

public class DataSource {
	
	private String driver_class;
	private String url;
	private String username;
	private String password;
	public String getDriver_class() {
		return driver_class;
	}
	public void setDriver_class(String driver_class) {
		this.driver_class = driver_class;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public DataSource() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DataSource(String driver_class, String url, String username, String password) {
		super();
		this.driver_class = driver_class;
		this.url = url;
		this.username = username;
		this.password = password;
	}
	
	

}
