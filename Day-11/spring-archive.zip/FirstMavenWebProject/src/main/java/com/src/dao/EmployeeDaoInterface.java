package com.src.dao;

import java.util.ArrayList;

import com.src.model.Employee;

public interface EmployeeDaoInterface {
	
	public void getConnection();	
	public boolean validateEmployee(Employee e);
	public int insertEmployee(Employee e);
	public int deleteEmployee(Employee e);
	public int editEmployee(Employee e);
	public ArrayList<Employee> displayEmployees();
	public Employee getEmployeeById(String id);	
	public void closeConnection();

}
