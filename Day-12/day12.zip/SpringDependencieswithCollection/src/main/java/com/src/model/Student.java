package com.src.model;

import java.util.List;

public class Student {
	
	private int stdid;
	private String stdname;
	private List<Address> stdaddress;
	
	public int getStdid() {
		return stdid;
	}
	public void setStdid(int stdid) {
		this.stdid = stdid;
	}
	public String getStdname() {
		return stdname;
	}
	public void setStdname(String stdname) {
		this.stdname = stdname;
	}
	public List<Address> getStdaddress() {
		return stdaddress;
	}
	public void setStdaddress(List<Address> stdaddress) {
		this.stdaddress = stdaddress;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int stdid, String stdname, List<Address> stdaddress) {
		
		this.stdid = stdid;
		this.stdname = stdname;
		this.stdaddress = stdaddress;
	}
	@Override
	public String toString() {
		return "Student [stdid=" + stdid + ", stdname=" + stdname + ", stdaddress=" + stdaddress + "]";
	}
	
	
	
	
	
	
	
	

}
