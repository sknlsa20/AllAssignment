package com.src.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.src.dao.EmployeeDAO;
import com.src.dao.EmployeeDaoInterface;
import com.src.model.Employee;

/**
 * Servlet implementation class MyController
 */
public class MyController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String mode=request.getParameter("mode");
		
		EmployeeDaoInterface edo = new EmployeeDAO();
		
		if(mode.equalsIgnoreCase("validate"))
		{
			String empid = request.getParameter("eid");
			String emppwd = request.getParameter("epwd");
			Employee e =new Employee();
			e.setEmpId(empid);
			e.setEmpPwd(emppwd);
			edo.getConnection();
			boolean result=edo.validateEmployee(e);
			if(result)
			{
				ArrayList<Employee> employees=edo.displayEmployees();
				HttpSession session = request.getSession(true);
				session.setAttribute("emps", employees);				
				response.sendRedirect("display.jsp");				
			}	
			else
			{
				response.sendRedirect("index.jsp?msg='invalid username or password'");
			}
			edo.closeConnection();
		}
		else if(mode.equalsIgnoreCase("add"))
		{
			String eid=request.getParameter("eid");
			String epwd=request.getParameter("epwd");
			String ename=request.getParameter("ename");
			int eage=Integer.parseInt(request.getParameter("eage"));
			long emob=Long.parseLong(request.getParameter("emob"));
			String eadd=request.getParameter("eadd");
			
			Employee e=new Employee(eid,epwd,ename,eage,emob,eadd);
			
			edo.getConnection();
			int result = edo.insertEmployee(e);
			ArrayList<Employee> employees=edo.displayEmployees();
			HttpSession session = request.getSession(true);
			session.setAttribute("emps", employees);
			if(result>0)
			{
								
				response.sendRedirect("display.jsp");	
			}
			else
			{
				response.sendRedirect("display.jsp?msg='cannot add employee'");
			}
			edo.closeConnection();
			
			
		}
		else if(mode.equalsIgnoreCase("delete"))
		{
			String eid=request.getParameter("id");
			
			Employee e=new Employee();
			e.setEmpId(eid);			
			edo.getConnection();
			int result = edo.deleteEmployee(e);
			ArrayList<Employee> employees=edo.displayEmployees();
			HttpSession session = request.getSession(true);
			session.setAttribute("emps", employees);
			if(result>0)
			{
								
				response.sendRedirect("display.jsp");	
			}
			else
			{
				response.sendRedirect("display.jsp?msg='cannot add employee'");
			}
			edo.closeConnection();
		}
		else if(mode.equalsIgnoreCase("editemp"))
		{
			
			String eid=request.getParameter("id");					
			edo.getConnection();
			Employee e = edo.getEmployeeById(eid);
			HttpSession session = request.getSession(true);
			session.setAttribute("emp", e);			
								
				response.sendRedirect("registration.jsp?msg=edit");	
			
			edo.closeConnection();
		}
		else if(mode.equalsIgnoreCase("edit"))
		{
			String eid=request.getParameter("eid");
			String epwd=request.getParameter("epwd");
			String ename=request.getParameter("ename");
			int eage=Integer.parseInt(request.getParameter("eage"));
			long emob=Long.parseLong(request.getParameter("emob"));
			String eadd=request.getParameter("eadd");
			
			Employee e=new Employee(eid,epwd,ename,eage,emob,eadd);
			
			edo.getConnection();
			int result = edo.editEmployee(e);
			ArrayList<Employee> employees=edo.displayEmployees();
			HttpSession session = request.getSession(true);
			session.setAttribute("emps", employees);
			if(result>0)
			{
								
				response.sendRedirect("display.jsp");	
			}
			else
			{
				response.sendRedirect("display.jsp?msg='cannot edit employee'");
			}
			edo.closeConnection();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
