package com.src.model;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanConfigurationClass {
	
	@Bean(name="std")
	public Student getStudent1()
	{
		return new Student(234,"james",getAddress1());
	}
	
	@Bean(name="add")
	public Address getAddress1()
	{
		return new Address(567,"my city","my state","my country",60007);
	}
	
	@Bean(name="std1")
	public Student getStudent2()
	{
		Student s = new Student();
		s.setStdid(456);
		s.setStdname("max");
		s.setStdadd(getAddress2());
		return s;
	}
	
	@Bean(name="add1")
	public Address getAddress2()
	{
		Address ad = new Address();
		ad.setHno(666);
		ad.setCity("punjab");
		ad.setState("hariyana");
		ad.setStreetname("mahathma gadhi city ");
		ad.setPincode(54545454);
		
		return ad;
	}
	
	

}
