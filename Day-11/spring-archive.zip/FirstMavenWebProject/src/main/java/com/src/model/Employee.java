package com.src.model;

public class Employee {
	
	private String empId;
	private String empPwd;
	private String empName;
	private int empAge;
	private long empmobile;
	private String empaddress;
	
	
	public Employee(String empId, String empPwd, String empName, int empAge, long empmobile, String empaddress) {
		
		this.empId = empId;
		this.empPwd = empPwd;
		this.empName = empName;
		this.empAge = empAge;
		this.empmobile = empmobile;
		this.empaddress = empaddress;
	}
	public Employee() {
		
		
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpPwd() {
		return empPwd;
	}
	public void setEmpPwd(String empPwd) {
		this.empPwd = empPwd;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpAge() {
		return empAge;
	}
	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}
	public long getEmpmobile() {
		return empmobile;
	}
	public void setEmpmobile(long empmobile) {
		this.empmobile = empmobile;
	}
	public String getEmpaddress() {
		return empaddress;
	}
	public void setEmpaddress(String empaddress) {
		this.empaddress = empaddress;
	}
	
	
	

}
