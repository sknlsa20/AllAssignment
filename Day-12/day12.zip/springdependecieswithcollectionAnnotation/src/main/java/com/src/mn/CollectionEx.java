package com.src.mn;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.src.conf.MyBeanConfiguration;
import com.src.model.Student;

public class CollectionEx {

	public static void main(String[] args) {


		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();		
		context.register(MyBeanConfiguration.class);		
		context.refresh();

		Student s= (Student) context.getBean("std");
		System.out.println(s);
		
		Student s1 = (Student) context.getBean("std1");		
	System.out.println(s1);
	}

}
