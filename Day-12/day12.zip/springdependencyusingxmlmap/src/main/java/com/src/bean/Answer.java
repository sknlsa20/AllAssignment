package com.src.bean;

public class Answer {
	
	private int ansid;
	private String ansvalue;
	public Answer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Answer(int ansid, String ansvalue) {
		super();
		this.ansid = ansid;
		this.ansvalue = ansvalue;
	}
	public int getAnsid() {
		return ansid;
	}
	public void setAnsid(int ansid) {
		this.ansid = ansid;
	}
	public String getAnsvalue() {
		return ansvalue;
	}
	public void setAnsvalue(String ansvalue) {
		this.ansvalue = ansvalue;
	}
	@Override
	public String toString() {
		return "Answer [ansid=" + ansid + ", ansvalue=" + ansvalue + "]";
	}
	
	

}
