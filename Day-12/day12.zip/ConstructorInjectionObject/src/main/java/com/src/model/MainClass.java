package com.src.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {

		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Student st=(Student) context.getBean("std");
		System.out.println(st);

		
		Student st1=(Student) context.getBean("std1");
		System.out.println(st1);
	}

}
