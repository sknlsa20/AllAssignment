package com.src.bean;

import java.util.Map;

public class Question {
	
	private int qid;
	private String qvalue;	
	private Map<User,Answer> qanswer;

	public Question() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Question(int qid, String qvalue, Map<User, Answer> qanswer) {
		super();
		this.qid = qid;
		this.qvalue = qvalue;
		this.qanswer = qanswer;
	}

	public int getQid() {
		return qid;
	}

	public void setQid(int qid) {
		this.qid = qid;
	}

	public String getQvalue() {
		return qvalue;
	}

	public void setQvalue(String qvalue) {
		this.qvalue = qvalue;
	}

	public Map<User, Answer> getQanswer() {
		return qanswer;
	}

	public void setQanswer(Map<User, Answer> qanswer) {
		this.qanswer = qanswer;
	}

	@Override
	public String toString() {
		return "Question [qid=" + qid + ", qvalue=" + qvalue + ", qanswer=" + qanswer + "]";
	}
	
	
	

}
