package com.src.model;

public class Address {
	
	private int hno;
	private String streetname;
	private String city;
	private String state;
	private long pin;
	public int getHno() {
		return hno;
	}
	public void setHno(int hno) {
		this.hno = hno;
	}
	public String getStreetname() {
		return streetname;
	}
	public void setStreetname(String streetname) {
		this.streetname = streetname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public long getPin() {
		return pin;
	}
	public void setPin(long pin) {
		this.pin = pin;
	}
	public Address(int hno, String streetname, String city, String state, long pin) {
		super();
		this.hno = hno;
		this.streetname = streetname;
		this.city = city;
		this.state = state;
		this.pin = pin;
	}
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Address [hno=" + hno + ", streetname=" + streetname + ", city=" + city + ", state=" + state + ", pin="
				+ pin + "]";
	}
	

}
