package com.src;

public class ShapeMainclass {

	public static void main(String[] args) {

		Triangle t =new Triangle();		
		t.draw();		
		Circle c =new Circle();
		c.draw();		
		Rectangle r=new Rectangle();		
		r.draw();
		
		
		Shape s = new Triangle();		
		s.draw();
		s= new Circle();
		s.draw();
		s=new Rectangle();
		s.draw();

	}

}
