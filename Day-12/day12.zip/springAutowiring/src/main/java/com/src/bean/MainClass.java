package com.src.bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {
	
	public static void main(String[] args) {
		
		
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");		
		DataBase db = (DataBase)context.getBean("db");		
		System.out.println(db);
		DataSource ds=db.getDs();	
		
		Student s=(Student) context.getBean("std");
		Connection con=null;
		PreparedStatement stmt=null;
		try {
			Class.forName(ds.getDriver_class());
			con=DriverManager.getConnection(ds.getUrl(), ds.getUsername(), ds.getPassword());			
			stmt=con.prepareStatement("insert into student121 values(?,?,?,?,?,?)");
			
			stmt.setString(1, s.getStdid());
			stmt.setString(3, s.getStdname());
			stmt.setString(2, s.getStdpwd());
			stmt.setInt(5,s.getStdage());
			stmt.setString(4, s.getStdaddress());
			stmt.setLong(6, s.getStdmob());
			
			
			int i = stmt.executeUpdate();
			
			if(i>0)
			{
				System.out.println("values inserted successfully");
			}
			else
			{
				System.out.println("unable to insert");
			}
			
			
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
