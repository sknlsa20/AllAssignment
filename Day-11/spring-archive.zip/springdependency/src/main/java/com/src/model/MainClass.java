package com.src.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.register(BeanConfigurationClass.class);
		context.refresh();
		
		Student st=(Student) context.getBean("std");
		System.out.println(st);

		Student st2=(Student) context.getBean("std1");
		System.out.println(st);
		
	}

}
